def test_sounds_like():
    from conceptnet5.util import sounds_like
    sounds_like.test()
