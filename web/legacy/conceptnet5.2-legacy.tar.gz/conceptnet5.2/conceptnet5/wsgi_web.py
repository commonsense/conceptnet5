from conceptnet5.web_interface.web_interface import app as application
