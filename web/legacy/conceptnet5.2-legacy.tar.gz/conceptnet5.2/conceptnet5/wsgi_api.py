from conceptnet5.api import app as application
