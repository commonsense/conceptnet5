The `input/` directory here contains a very small set of input data representing each input source, and `output/` contains the expected output when it is run through the appropriate reader. This is used for testing (see the `tests` directory).

To get the full set of input data for ConceptNet, run "make download" in the `data` directory.
